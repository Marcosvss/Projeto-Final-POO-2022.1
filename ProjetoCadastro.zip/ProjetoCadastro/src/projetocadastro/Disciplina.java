package projetocadastro;

import java.util.List;

class Disciplina {
    public String nome;
    public String Ch;
    public String tipo;

    
    public Disciplina(String nome, String Ch, String tipo) {
        this.nome = nome;
        this.Ch = Ch;
        this.tipo = tipo;
    }
    
    @Override
    public String toString() {
        return "Disciplina{" + "Nome: " + nome + ", CH: " + Ch + "h, Tipo: " + tipo + '}';
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCh() {
        return Ch;
    }

    public void setCh(String Ch) {
        this.Ch = Ch;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    
    
    


    
}
