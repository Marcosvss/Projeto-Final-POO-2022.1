package projetocadastro;

import java.util.ArrayList;

public class HoraComplementar implements HorasComplementares {
    private String categoria;
    private String Assunto;
    private String Horas;
    ArrayList<HoraComplementar> Lista2 = new ArrayList<>();

    public HoraComplementar(String categoria, String Assunto, String Horas) {
        this.categoria = categoria;
        this.Assunto = Assunto;
        this.Horas = Horas;
    }

    @Override
    public String toString() {
        return "Atividade complementar{" + "Tipo: " + categoria + ", Assunto: " + Assunto + ", Horas: " + Horas + '}';
    }

    
    
    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getAssunto() {
        return Assunto;
    }

    public void setAssunto(String Assunto) {
        this.Assunto = Assunto;
    }

    public String getHoras() {
        return Horas;
    }

    public void setHoras(String Horas) {
        this.Horas = Horas;
    }

    @Override
    public String somarHoras() {
        int i;
        int soma;
        String s;
        s = "inicio";
        soma = 0;
        for(i =0 ;i<Lista2.size();i++ ){
            
        soma = soma + Integer.parseInt(Lista2.get(i).getHoras());
            s = Integer.toString(soma);
    }
        return s;
        
    }

    

    
    
    
    
    
    
}
