package projetocadastro;

public class Main {

    public static void main(String[] args) {
        TelaC tela = new TelaC();
        tela.setVisible(true);

    }
    
}
